     
length=input("Enter length of the rectangle: ");
width=input("Enter width of the rectangle: ");
length=int(length)
width=int(width)
#Calculate perimeter of rectangle 
perimeter = 2 * (length + width)

#Print perimeter of rectangle 
print("Perimeter of rectangle="+str(perimeter)+" units")

