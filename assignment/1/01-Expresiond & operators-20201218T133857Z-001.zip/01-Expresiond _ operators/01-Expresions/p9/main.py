
print("Name   : IMT School") 
print("DOB    : Jan, 1, 2013") 
print("Mobile : 01019986337")
