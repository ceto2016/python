# C program to calculate total, average and percentage of five subjects

#Input marks of all five subjects
eng=input("Enter marks of english subject:")
phy=input("Enter marks of physics subject:")
chem=input("Enter marks of chemistry subject:")
math=input("Enter marks of math subject:")
comp=input("Enter marks of comp subject:")

#cast all values as an interger numbers
eng=int(eng)
phy=int(phy)
chem=int(chem)
math=int(math)
comp=int(comp)

#Calculate total, average and percentage
total = eng + phy + chem + math + comp
average = total / 5
percentage = (total / 500) * 100
#Print all results 
print("Total marks =",total)
print("Average marks =",average)
print("Percentage =",percentage)

