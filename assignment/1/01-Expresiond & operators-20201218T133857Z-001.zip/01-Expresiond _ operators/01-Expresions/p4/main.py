FirstNumber=input("please enter the first number:")
SecondNumber=input("please enter the second number:")

print("--------befor swapping--------------")
print("first number :",FirstNumber)
print("second number :",SecondNumber)

FirstNumber=int(FirstNumber)
SecondNumber=int(SecondNumber)

FirstNumber=FirstNumber+SecondNumber
SecondNumber=FirstNumber-SecondNumber
FirstNumber=FirstNumber-SecondNumber

print("--------after swapping--------------")
print("first number :",FirstNumber)
print("second number :",SecondNumber)