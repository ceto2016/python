
FirstNumber=input("please enter the floating first number ")
SecondNumber=input("please enter the floating second number ")
FirstNumber=float(FirstNumber)
SecondNumber=float(SecondNumber)
Mul=FirstNumber*SecondNumber

print("Mul="+str(Mul))