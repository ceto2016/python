Value_one=input("Enter integer value one")
Value_two=input("Enter integer value two")
Value_three=input("Enter integer value three")
Value_four=input("Enter integer value four")

Value_one=int(Value_one)
Value_two=int(Value_two)
Value_three=int(Value_three)
Value_four=int(Value_four)

if Value_three-Value_four !=0:
	Ratio=float(Value_one+Value_two)/float(Value_three-Value_four)
	message="Ratio is " +str(Ratio)
	print(message)
