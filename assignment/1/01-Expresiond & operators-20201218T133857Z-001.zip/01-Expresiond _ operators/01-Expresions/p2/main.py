number_1=input("Please Enter number 1: ")
number_2=input("Please Enter number 2: ")
number_1=int(number_1)
number_2=int(number_2)
Div=int(number_1/number_2)
Reminder=number_1%number_2
print("division="+str(Div))
print("reminder="+str(Reminder))