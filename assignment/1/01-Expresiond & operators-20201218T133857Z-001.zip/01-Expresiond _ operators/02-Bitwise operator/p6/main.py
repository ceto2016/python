#C program to check even or odd number using bitwise operator

#Input number from user
number=input("Enter any number: ")

#cast from string to int
number=int(number)
NewNumber=number&1

if NewNumber  == 1:
	print(str(number)+"is odd.")    
else :
	print(str(number)+"is even.")
