#C program to set the nth bit of a number

#Input number from user
num=input("Enter any number: ")
 
#Input bit position you want to set 
n=input("Enter nth bit to set (0-31): ")

#casting from string to int
num=int(num)
n=int(n)

#Left shift 1, n times and perform bitwise OR with num 
newNum = (1 << n) | num

print("Bit set successfully.");
print("Number before setting "+str(n)+" bit:"+str(num)+" (in decimal)")
print("Number after setting "+str(n)+" bit:"+str(newNum)+" (in decimal)")
