#program to get the nth bit of a number

#Input number from user
num=input("Enter any number: ")

#Input bit position you want to check
n=input("Enter nth bit to check (0-31): ");
#Right shift num, n times and perform bitwise AND with 1
num=int(num)
n=int(n)

bitStatus = (num >> n) & 1;
print("The "+str(n)+"bit is set to"+str(bitStatus));
