
#program to check Least Significant Bit (LSB) of a number using bitwise operator

#Input number from user
number=input("Enter any number: ")

#cast number from string to int
number=int(number)

#If (number & 1) evaluates to 1 
if number & 1 :
	print("LSB of "+ str(number)+" is set (1).")
else:
	print("LSB of "+ str(number)+" is set (0).")
