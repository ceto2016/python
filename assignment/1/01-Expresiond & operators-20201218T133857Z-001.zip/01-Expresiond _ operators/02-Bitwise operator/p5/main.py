#program to swap two numbers using bitwise operator
 
#Input two numbers from user 
FirstNumber=input("Enter the first number: ")
SecondNumber=input("Enter the second number: ")

print("before swapping")
print("Original value of first number ="+ FirstNumber)
print("Original value of second number ="+ SecondNumber)

#cast from string to int
FirstNumber=int(FirstNumber)
SecondNumber=int(SecondNumber)

#Swap two numbers 
FirstNumber ^= SecondNumber;
SecondNumber ^= FirstNumber;
FirstNumber ^= SecondNumber;

print("after swapping")
print("first number  after swapping ="+str(FirstNumber))
print("second number after swapping ="+str(SecondNumber))
