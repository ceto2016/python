#program to count flip all bits of a binary number using bitwise operator

#Input number from user
num=input("Enter any number: ")

num=int(num)
flippedNumber = ~num;

print("Original number ="+str(num)+"(in decimal)");
print("Number after bits are flipped = "+str(flippedNumber)+"(in decimal)");
